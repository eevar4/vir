1. Run Node server for consuming API
*********************************
unzip the vir folder and run below commands
1. cd api
2. npm install 
3. npm run serve

2. Run UI
*********************************
unzip the folder myapp 
go to -> dist folder -> copy myapp folder and paste into ROOT Folder in tomcat/apache
EX: ...\tomcat\webapps\ROOT

Note: If you want to run in angular environment run the below commands
unzip the folder myapp 
cd myapp
npm install
ng serve

** Please install node js

Login Credential:
username: admin
password: admin