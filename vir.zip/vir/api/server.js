
const express = require("express")
  , bodyParser = require("body-parser")
  , cors = require("cors")
  , port = 4040;

const app = express();
app.use(bodyParser.json());
app.use(cors());

app.post("/api/authenticate", (req, res) => {
  if (req.body.username !== 'admin' || req.body.password !== 'admin') {
    res.sendStatus(401);
  }

  res.json({
    jwt_token: "########"
  });
});

app.get("/api/getUser", (req, res) => {
  const authHeader = req.headers.authorization;
  if (authHeader === undefined) {
    return res.sendStatus(401);
  }

  res.json({ firstName: 'admin', lastName: 'admin' });
});

app.post("/api/v1/parse", (req, res) => {
  const authHeader = req.headers.authorization;
  if (authHeader === undefined) {
    return res.sendStatus(401);
  }

  const result = getArrayData(req.body.data, 'v1');
  const [
    firstName,
    lastName,
    clientId
  ] = [...result];

  res.json({ firstName: firstName, lastName: lastName, clientId: clientId });
});

app.post("/api/v2/parse", (req, res) => {
  const authHeader = req.headers.authorization;
  if (authHeader === undefined) {
    return res.sendStatus(401);
  }

  const result = getArrayData(req.body.data, 'v2');
  const [
    firstName,
    lastName,
    clientId
  ] = [...result];

  res.json({ firstName: firstName, lastName: lastName, clientId: clientId });
});

app.listen(port, () => {
  console.log(`Server started at port ${port}!!!`);
});

function getArrayData(data, v) {
  let lastChar
    , j = 0
    , result = ['', '', ''];

  for (i = 0; i < data.length; i++) {

    if (lastChar == 0 & data[i] != 0)
      j++;

    let char = (data[i] == 0 && v === 'v2') ? '' : data[i];
    result[j] = result[j] + char;
    lastChar = data[i];
  }

  return result;
}