import { environment } from  './../environments/environment';

export const CONFIG =   {
    SERVER_API_URL  :   environment.SERVER_API_URL,
    SERVER_ASSET_URL: environment.SERVER_ASSET_URL
}