import { Component, AfterViewInit, ElementRef, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, Validators } from '@angular/forms';
import { LoginService } from '../../../core/services/auth/login.service';
import { AuthService } from '../../../core/services/auth/authentication.service';
 
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements AfterViewInit {
  @ViewChild('userName', {static: false})
  userName:ElementRef;
  loginError=false;

  loginForm = this.formBuilder.group({
    username: [''],
    password: [''],
  });

  constructor(
    private formBuilder: FormBuilder,
    private loginService: LoginService,
    private authService: AuthService,
    private router: Router
  ) { }  

  ngOnInit(): void {
    
  }

  ngAfterViewInit(): void {    
    if (this.userName) {
      this.userName.nativeElement.focus();
    }
  }

  login(): void {
    if(this.loginForm.valid) {
      this.loginService.login(this.loginForm.value).subscribe(() => {
        this.loginError = false;

        if(this.authService.isAuthenticated()) {
          this.router.navigate(['admin']);
        }

      },
      (error) => this.loginError = true
    )};
  }
}
