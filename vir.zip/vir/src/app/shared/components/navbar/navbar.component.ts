import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SessionStorageService } from 'ngx-webstorage';
import { LoginService } from './../../../core/services/auth/login.service';
import { AuthService } from './../../../core/services/auth/authentication.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['navbar.scss'],
})
export class NavbarComponent implements OnInit {
  inProduction?: boolean;
  isNavbarCollapsed = true;

  constructor(
    private loginService: LoginService,
    private authService: AuthService,
    private router: Router
  ) {
     
  }

  ngOnInit(): void {
   
  }

  changeLanguage(languageKey: string): void {
  }

  collapseNavbar(): void {
    this.isNavbarCollapsed = true;
  }

  isAuthenticated(): boolean {
    let ret=this.authService.isAuthenticated();
    return ret;
  }

  logout(): void {
    this.collapseNavbar();
    this.loginService.logout();
    this.router.navigate(['']);
  }

  toggleNavbar(): void {
    this.isNavbarCollapsed = !this.isNavbarCollapsed;
  }
}
