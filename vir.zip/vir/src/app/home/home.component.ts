import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from './../core/services/auth/authentication.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  showLogin=false;
  
  constructor(  
    private router: Router,
    private authService: AuthService,
  ) { }

  ngOnInit(): void {
    this.authService.identifyUser().subscribe(()=>{
      if(this.authService.isAuthenticated()){
        this.router.navigate(['admin']);
      }
      else {
        this.showLogin  = true;
      }
    });    
  }
}
