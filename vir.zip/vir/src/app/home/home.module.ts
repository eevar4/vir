import { NgModule } from '@angular/core';
import { SharedModule } from './../shared/shared.module';
import { HomeComponent } from './home.component';
import { Route, RouterModule } from '@angular/router';

const ROUTES: Route  = { 
    path: '',    
    component: HomeComponent
};

@NgModule({
  declarations: [HomeComponent],
  imports: [
    SharedModule,
    RouterModule.forChild([ROUTES])    
  ]
})
export class HomeModule { }
