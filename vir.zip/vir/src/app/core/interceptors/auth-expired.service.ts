import  { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { LoginService } from './../services/auth/login.service';
import { Router } from '@angular/router';
import { StateStorageService } from './../services/auth/state-storage.service';

@Injectable()
export class AuthExpiredInterceptor implements HttpInterceptor {
    constructor(
        private router: Router,
        private loginService: LoginService,
        private stateStorageService: StateStorageService
    ){ }

    intercept(httpRequest: HttpRequest<any>, httpHandler: HttpHandler): Observable<HttpEvent<any>>{
        return httpHandler.handle(httpRequest).pipe(
            tap(null, (httpErrorReponse: HttpErrorResponse) =>  {
                if (httpErrorReponse.status === 401 && httpErrorReponse.url && !httpErrorReponse.url.includes('api/getUser')) {
                    this.stateStorageService.storeUrl(this.router.routerState.snapshot.url);
                    this.loginService.logout();
                    this.router.navigate(['']);
                }
            })
        )
    }
}