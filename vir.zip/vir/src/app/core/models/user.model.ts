export interface IUser {
    firstName: string;
    lastName: string;
    email: boolean;
  }
  
  export class User implements IUser {
    constructor(public firstName: string, public lastName: string, public email: boolean) {
    }
  }
  