import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AuthExpiredInterceptor } from './interceptors/auth-expired.service';
import { AuthTokenInterceptor } from './interceptors/auth-token.interceptor';
import { NgxWebstorageModule } from 'ngx-webstorage';

@NgModule({
  imports: [
    CommonModule,
    HttpClientModule,
    NgxWebstorageModule.forRoot({ prefix: 'jouve', separator: '-' }),
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthExpiredInterceptor,
      multi: true,
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthTokenInterceptor,
      multi: true,
    }
  ],
  declarations: []
})
export class CoreModule { }