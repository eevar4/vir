import { core } from '@angular/compiler';

export * from './core.module';