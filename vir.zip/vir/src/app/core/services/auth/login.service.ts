import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { flatMap } from 'rxjs/operators';

import { AuthService } from './authentication.service';
import { Login } from './../../models/login.model'

@Injectable({ providedIn: 'root' })
export class LoginService {
  constructor(
      private authService: AuthService
    ) {}

  login(userCredentials: Login): Observable<any | null> {
    return this.authService.userLogin(userCredentials).pipe(
        flatMap(() => this.authService.identifyUser(true))
    );
  }

  logout(): void {
    this.authService.logout().subscribe(null, null, () => this.authService.authenticate(null));
  }
}
