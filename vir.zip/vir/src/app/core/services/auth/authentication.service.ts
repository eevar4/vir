import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CONFIG } from 'app/app.config';
import { Login } from 'app/core/models/login.model';
import { User } from 'app/core/models/user.model';
import { map, catchError, tap, shareReplay, min } from 'rxjs/operators';
import { Observable, ReplaySubject, of } from 'rxjs';
import { SessionStorageService } from 'ngx-webstorage';

type JwtToken = {
  jwt_token: string;
};

@Injectable({providedIn: 'root'})
export class AuthService {
    private userData: User | null = null;
    private authenticationState = new ReplaySubject<User | null>(1);
    private userDataCache: Observable<User | null>;
    
    constructor(
        private httpClient: HttpClient,
        private sessionStorage: SessionStorageService    
    ){
    }

    getToken(): string {
        return this.sessionStorage.retrieve('authenticationToken') || '';
    }    
    
    userLogin(userCredential: Login): Observable<void> {
        return this.httpClient.post<any>(CONFIG.SERVER_API_URL+ 'api/authenticate', userCredential)
            .pipe(map(res => {
                this.setJWT(res);
            }));
    }

    private getUser(): Observable<User> {
        return this.httpClient.get<User>(CONFIG.SERVER_API_URL + 'api/getUser');
    }

    authenticate(userData: User | null): void {
        this.userData = userData;
        this.authenticationState.next(this.userData);
    }
    
    getAuthenticationState(): Observable<User | null> {
        return this.authenticationState.asObservable();
    }

    isAuthenticated(): boolean {
        return this.userData !== null;
    }

    identifyUser(force?: boolean): Observable<User | null> {

        if (!this.userDataCache || force || !this.isAuthenticated()) {
          this.userDataCache = this.getUser().pipe(
            catchError(() => {
              return of(null);
            }),
            tap((user: User | null) => {
              this.authenticate(user);    
            }),
            shareReplay()
          );
        }

        return this.userDataCache;
    }

    private setJWT(response: JwtToken): void {
        const jwt = response.jwt_token;
        this.sessionStorage.store('authenticationToken', jwt);
    }

    logout(): Observable<void> {
      return new Observable(observer => {
        this.sessionStorage.clear('authenticationToken');
        observer.complete();
      });
    }
}
