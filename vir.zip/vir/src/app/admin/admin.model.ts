export interface IAdmin {
    firstName: string;
    lastName: string;
    clientId: string;
}

export class Admin implements IAdmin {
    constructor(
        public firstName: string,
        public lastName: string,
        public clientId: string,
    ){

    }
}