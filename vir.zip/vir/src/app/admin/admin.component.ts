import { Component, OnInit } from '@angular/core';
import { AdminService } from './admin.service';
import { FormBuilder, Validators, FormGroup } from '@angular/forms'

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss'] 
})

export class AdminComponent implements OnInit {
  dataForm:FormGroup;
  sampleData  = 'JOHN0000MICHAEL0009994567';
  result: any;
  error:any;
  constructor(
    private adminService: AdminService,
    private formBuilder: FormBuilder
  ) { }

  ngOnInit() {
    this.dataForm = this.formBuilder.group({
      data: [this.sampleData, Validators.required]      
    });
  }

  fetchData(version: string): void {
    if(this.dataForm.valid) {
      this.adminService.fetchData(this.dataForm.value, version).subscribe((data) => {
        this.result={
          firstName: data.firstName,
          lastName: data.lastName,
          clientId: data.clientId
        };
      }, 
      (error) => {
        this.error=error;
        setTimeout(()=> {
          this.error='';
        }, 3000)
      })
    }
  }

  reset(): void {
    this.dataForm.reset();
  }
}
