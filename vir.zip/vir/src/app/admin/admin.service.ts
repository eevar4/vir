import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CONFIG } from 'app/app.config';
import { Admin } from './admin.model';
 
@Injectable({ providedIn: 'root' })
export class AdminService {
  constructor(
    private httpClient: HttpClient
  ) {

  }

  public fetchData(formData: any, version: string): Observable<Admin> {
    const apiUrl = (version == 'V1') ? 'api/v1/parse' : 'api/v2/parse';
    return this.httpClient.post<Admin>(CONFIG.SERVER_API_URL + apiUrl, formData);
  }
}
