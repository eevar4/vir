export const environment = {
  production: true,
  SERVER_API_URL: 'http://localhost:4040/',
  SERVER_ASSET_URL: window.location.origin+'/testapp/assets/'
};
